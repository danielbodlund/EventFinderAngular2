"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var my_events_service_1 = require('../my-events.service');
var MyTileComponent = (function () {
    function MyTileComponent(das, _ngZone) {
        this.das = das;
        this._ngZone = _ngZone;
        this.event = {};
    }
    MyTileComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.das.getEvent(this.eventId).then(function (result) {
            _this._ngZone.run(function () {
                _this.event = result;
            });
        });
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], MyTileComponent.prototype, "eventId", void 0);
    MyTileComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'my-tile',
            templateUrl: 'my-tile.component.html',
            styleUrls: ['my-tile.component.css'],
            providers: [my_events_service_1.MyEventsService]
        }), 
        __metadata('design:paramtypes', [my_events_service_1.MyEventsService, core_1.NgZone])
    ], MyTileComponent);
    return MyTileComponent;
}());
exports.MyTileComponent = MyTileComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-tile/my-tile.component.js.map