"use strict";
var my_tile_component_1 = require('./my-tile.component');
exports.MyTileComponent = my_tile_component_1.MyTileComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-tile/index.js.map