"use strict";
var my_event_container_component_1 = require('./my-event-container.component');
exports.MyEventContainerComponent = my_event_container_component_1.MyEventContainerComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-event-container/index.js.map