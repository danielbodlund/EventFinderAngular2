"use strict";
var testing_1 = require('@angular/core/testing');
var date_handler_service_1 = require('./date-handler.service');
testing_1.describe('DateHandler Service', function () {
    testing_1.beforeEachProviders(function () { return [date_handler_service_1.DateHandlerService]; });
    testing_1.it('should ...', testing_1.inject([date_handler_service_1.DateHandlerService], function (service) {
    }));
});
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/date-handler.service.spec.js.map