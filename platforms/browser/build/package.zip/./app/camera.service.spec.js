"use strict";
var testing_1 = require('@angular/core/testing');
var camera_service_1 = require('./camera.service');
testing_1.describe('Camera Service', function () {
    testing_1.beforeEachProviders(function () { return [camera_service_1.CameraService]; });
    testing_1.it('should ...', testing_1.inject([camera_service_1.CameraService], function (service) {
        testing_1.expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/camera.service.spec.js.map