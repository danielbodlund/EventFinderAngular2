"use strict";
var testing_1 = require('@angular/core/testing');
var event_data_service_1 = require('./event-data.service');
testing_1.describe('MockEvent Service', function () {
    testing_1.beforeEachProviders(function () { return [event_data_service_1.EventDataService]; });
    testing_1.it('should ...', testing_1.inject([event_data_service_1.EventDataService], function (service) {
    }));
});
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/event-data.service.spec.js.map