"use strict";
var my_carousel_component_1 = require('./my-carousel.component');
exports.MyCarouselComponent = my_carousel_component_1.MyCarouselComponent;
//Test for Daniel; 
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-carousel/index.js.map