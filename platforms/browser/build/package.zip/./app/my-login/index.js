"use strict";
var my_login_component_1 = require('./my-login.component');
exports.MyLoginComponent = my_login_component_1.MyLoginComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-login/index.js.map