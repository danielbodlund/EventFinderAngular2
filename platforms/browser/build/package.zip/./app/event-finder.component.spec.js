"use strict";
var testing_1 = require('@angular/core/testing');
var event_finder_component_1 = require('../app/event-finder.component');
testing_1.beforeEachProviders(function () { return [event_finder_component_1.EventFinderApp]; });
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/event-finder.component.spec.js.map