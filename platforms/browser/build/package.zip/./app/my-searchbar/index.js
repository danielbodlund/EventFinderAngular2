"use strict";
var my_searchbar_component_1 = require('./my-searchbar.component');
exports.MySearchbarComponent = my_searchbar_component_1.MySearchbarComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-searchbar/index.js.map