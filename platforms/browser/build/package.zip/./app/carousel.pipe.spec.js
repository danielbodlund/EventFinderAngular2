// import {
//   it,
//   iit,
//   describe,
//   ddescribe,
//   expect,
//   inject,
//   injectAsync,
//   TestComponentBuilder,
//   beforeEachProviders
// } from 'angular2/testing';
// import {provide} from 'angular2/core';
// import {Carousel} from './carousel.pipe';
// describe('Carousel Pipe', () => {
//   beforeEachProviders(() => [Carousel]);
//   it('should transform the input', inject([Carousel], (pipe:Carousel) => {
//       expect(pipe.transform(true)).toBe(null);
//   }));
// });
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/carousel.pipe.spec.js.map