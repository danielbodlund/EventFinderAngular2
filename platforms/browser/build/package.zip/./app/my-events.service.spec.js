"use strict";
var testing_1 = require('@angular/core/testing');
var my_events_service_1 = require('./my-events.service');
testing_1.describe('MyEvents Service', function () {
    testing_1.beforeEachProviders(function () { return [my_events_service_1.MyEventsService]; });
    testing_1.it('should ...', testing_1.inject([my_events_service_1.MyEventsService], function (service) {
    }));
});
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-events.service.spec.js.map