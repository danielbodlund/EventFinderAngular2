"use strict";
var my_user_events_component_1 = require('./my-user-events.component');
exports.MyUserEventsComponent = my_user_events_component_1.MyUserEventsComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-user-events/index.js.map