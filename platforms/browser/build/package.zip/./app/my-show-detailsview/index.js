"use strict";
var my_show_detailsview_component_1 = require('./my-show-detailsview.component');
exports.MyShowDetailsviewComponent = my_show_detailsview_component_1.MyShowDetailsviewComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-show-detailsview/index.js.map