"use strict";
var testing_1 = require('@angular/core/testing');
var my_users_service_1 = require('./my-users.service');
testing_1.describe('MyUsers Service', function () {
    testing_1.beforeEachProviders(function () { return [my_users_service_1.MyUsersService]; });
    testing_1.it('should ...', testing_1.inject([my_users_service_1.MyUsersService], function (service) {
    }));
});
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-users.service.spec.js.map