"use strict";
var my_create_account_component_1 = require('./my-create-account.component');
exports.MyCreateAccountComponent = my_create_account_component_1.MyCreateAccountComponent;
//# sourceMappingURL=/Users/iths/Documents/EventFinder2/EventFinderAngular2/tmp/broccoli_type_script_compiler-input_base_path-IB1kZtRz.tmp/0/app/my-create-account/index.js.map